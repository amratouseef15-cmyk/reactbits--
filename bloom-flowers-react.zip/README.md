# Bloom — Flower Shop React Website

A responsive flower-shop landing page built with React and Vite.

## Features
- Soft, floral visual theme and responsive layout
- Flower product cards with sample prices and descriptions
- Category filters and live search
- Favourite/like buttons
- Add-to-bag counter (demo client-side state)
- Animated hero bouquet and story section

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Upload to GitHub
1. Extract the ZIP file.
2. Create a new repository on GitHub.
3. Upload the extracted project files and folders.
4. Commit the changes.

The product listings, prices and emoji artwork are sample content. Replace them with your own flower photos and shop details before publishing. Google Fonts are loaded from an external stylesheet.
