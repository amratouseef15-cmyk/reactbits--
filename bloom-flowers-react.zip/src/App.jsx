import { useMemo, useState } from 'react';
import { ArrowRight, Flower2, Heart, Leaf, Menu, Search, ShoppingBag, Sparkles } from 'lucide-react';

const flowers = [
  {id:1,name:'Rosy Romance',type:'Roses',price:1299,tag:'BESTSELLER',emoji:'🌹',tone:'rose',desc:'A classic bunch of soft pink roses.'},
  {id:2,name:'Sunny Days',type:'Sunflowers',price:999,tag:'BRIGHT & HAPPY',emoji:'🌻',tone:'sun',desc:'Bring a little sunshine to their day.'},
  {id:3,name:'Pastel Dreams',type:'Mixed',price:1599,tag:'FRESH PICK',emoji:'💐',tone:'lilac',desc:'A dreamy mix of seasonal blooms.'},
  {id:4,name:'Pure Elegance',type:'Lilies',price:1399,tag:'TIMELESS',emoji:'🤍',tone:'cream',desc:'Elegant white blooms for every occasion.'},
  {id:5,name:'Violet Haze',type:'Mixed',price:1199,tag:'JUST BECAUSE',emoji:'🪻',tone:'violet',desc:'Gentle colours with a little magic.'},
  {id:6,name:'Tulip Love',type:'Tulips',price:1499,tag:'LOVED BY ALL',emoji:'🌷',tone:'tulip',desc:'Fresh tulips to make them smile.'}
];
const money = n => '₹' + n.toLocaleString('en-IN');

function App(){
  const [category,setCategory]=useState('All');
  const [query,setQuery]=useState('');
  const [likes,setLikes]=useState([]);
  const [bag,setBag]=useState([]);
  const categories=['All','Roses','Sunflowers','Lilies','Tulips','Mixed'];
  const shown=useMemo(()=>flowers.filter(f=>(category==='All'||f.type===category)&&`${f.name} ${f.type}`.toLowerCase().includes(query.toLowerCase())),[category,query]);
  const add=id=>setBag(old=>[...old,id]);
  return <main>
    <div className="announcement">A LITTLE JOY, DELIVERED FRESH <span>✿</span> FREE DELIVERY ON ORDERS OVER ₹1,999</div>
    <header className="nav wrap">
      <a className="logo" href="#"><span className="logo-icon"><Flower2 size={22}/></span> bloom<span>.</span></a>
      <nav><a href="#shop">Shop flowers</a><a href="#story">Our story</a><a href="#contact">Contact</a></nav>
      <button className="bag" onClick={()=>document.getElementById('shop').scrollIntoView({behavior:'smooth'})}><ShoppingBag size={17}/> <span>Bag ({bag.length})</span></button>
    </header>
    <section className="hero wrap">
      <div className="hero-text"><div className="eyebrow"><Sparkles size={14}/> FLOWERS THAT SAY IT ALL</div>
        <h1>Make life<br/>a little more <em>bloomful.</em></h1>
        <p>Thoughtful flowers for big celebrations, tiny moments, and everything in between.</p>
        <a className="button" href="#shop">Explore the blooms <ArrowRight size={17}/></a>
        <div className="note"><span>✿</span> Handpicked with love · Wrapped with care</div>
      </div>
      <div className="hero-art"><div className="sun-disc"></div><div className="hero-bouquet">💐</div><div className="hero-sticker">made with<br/><b>love</b> ♡</div><div className="hero-caption">FRESH FLOWERS, HAPPY HEARTS</div></div>
    </section>
    <section className="perks wrap"><div><span>✿</span><b>Fresh every day</b><small>Beautiful blooms, always</small></div><div><span>♡</span><b>Made with love</b><small>Arranged by hand</small></div><div><span>♧</span><b>Delivered with care</b><small>A lovely surprise awaits</small></div></section>
    <section className="shop wrap" id="shop">
      <div className="section-head"><div><div className="eyebrow">THE FLOWER BAR</div><h2>Find your <em>favourite.</em></h2></div><p>Little bundles of happiness,<br/>ready to brighten someone's day.</p></div>
      <div className="tools"><div className="filters">{categories.map(c=><button key={c} onClick={()=>setCategory(c)} className={category===c?'active':''}>{c}</button>)}</div><label className="search"><Search size={16}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Find a flower..."/></label></div>
      <div className="grid">{shown.map(f=><article className="flower-card" key={f.id}><div className={`flower-image ${f.tone}`}><span className="flower-emoji">{f.emoji}</span><span className="tag">{f.tag}</span><button className={likes.includes(f.id)?'heart liked':'heart'} onClick={()=>setLikes(old=>old.includes(f.id)?old.filter(x=>x!==f.id):[...old,f.id])} aria-label="Save flower"><Heart size={18} fill={likes.includes(f.id)?'currentColor':'none'}/></button></div><div className="details"><div className="type">{f.type}</div><div className="product-line"><h3>{f.name}</h3><b>{money(f.price)}</b></div><p>{f.desc}</p><button className="add" onClick={()=>add(f.id)}>Add to bag <span>+</span></button></div></article>)}</div>
      {shown.length===0&&<p className="empty">No flowers found. Try another search.</p>}
    </section>
    <section className="quote wrap" id="story"><div className="quote-flower">🌸</div><div className="eyebrow">A NOTE FROM BLOOM</div><h2>Flowers are little<br/>reminders that <em>beauty grows.</em></h2><p>We believe the smallest gestures can make the biggest memories. That's why every bouquet is prepared with care, a creative touch, and lots of love.</p><a href="#shop">Send someone flowers <ArrowRight size={16}/></a></section>
    <footer id="contact"><div className="wrap foot"><a className="logo" href="#"><span className="logo-icon"><Flower2 size={21}/></span> bloom<span>.</span></a><span>Flowers for every feeling. ♡</span><span>© 2026 BLOOM FLOWER CO.</span></div></footer>
  </main>
}
export default App;